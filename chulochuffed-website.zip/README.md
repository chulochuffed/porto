# Chulo Chuffed — Personal Branding Website

Website personal branding untuk **Chulo Chuffed** — *Ethical Hacker • Security Researcher • Bug Hunter • Developer*.
Dibangun murni dengan **HTML, CSS, dan JavaScript** (tanpa framework/library eksternal, kecuali Font Awesome untuk ikon dan Google Fonts untuk tipografi), bertema **cybersecurity dark-mode / blue neon glassmorphism**.

🔗 Live: `https://chulochuffed.is-a.dev`

---

## ✨ Fitur

- Hero fullscreen dengan efek **typing animation**, **matrix-style canvas background**, animated grid, dan glow.
- Terminal simulasi (`whoami`) sebagai elemen signature bertema hacker.
- Navbar transparan yang berubah solid saat discroll, lengkap dengan **active navigation** dan mobile menu responsif.
- **Scroll reveal animation**, **hover animation**, **ripple effect** pada tombol/card, **cursor glow**, **custom scrollbar**, dan **back to top button**.
- Section: Home, About, Skills (progress bar animasi), Portfolio, Blog, Contact (Font Awesome icons), Footer.
- **SEO-ready**: meta title/description/keywords, Open Graph, Twitter Card, `robots.txt`, `sitemap.xml`, canonical URL.
- **Lazy loading** untuk gambar, semantic HTML5, dan aksesibilitas dasar (skip link, `aria-*`, fokus keyboard terlihat, `prefers-reduced-motion` dihormati).
- Struktur kode modular dan mudah dikembangkan.

---

## 📁 Struktur Proyek

```
chulochuffed/
├── index.html          # Struktur halaman (semantic HTML5)
├── style.css            # Semua styling (design tokens di :root)
├── script.js             # Semua interaksi (modular, per-fitur)
├── assets/
│   ├── images/           # Thumbnail portfolio, blog, dan OG cover (SVG)
│   └── icons/             # Favicon (SVG)
├── robots.txt
├── sitemap.xml
└── README.md
```

---

## 🎨 Kustomisasi Cepat

### Mengganti Warna
Semua warna didefinisikan sebagai CSS variable di bagian atas `style.css`:

```css
:root {
  --color-bg: #05070a;      /* Warna latar utama */
  --color-neon: #00d9ff;    /* Aksen biru neon */
  --color-neon-2: #2b6bff;  /* Aksen biru neon kedua (gradient) */
  --color-text: #eaf3ff;    /* Warna teks utama */
  ...
}
```

Ubah nilai-nilai ini untuk mengganti seluruh skema warna website secara konsisten.

### Mengganti Konten
- **Role di hero (typing effect):** edit array `roles` di `script.js` pada fungsi `initTypingEffect()`.
- **Teks About, Skills, dll:** edit langsung di `index.html`, setiap section diberi komentar penanda.
- **Portfolio & Blog:** duplikasi `<article class="project-card ...">` atau `<article class="blog-card ...">` yang sudah ada, lalu ganti gambar, judul, deskripsi, dan link.
- **Email kontak:** ganti `href="mailto:youremail@example.com"` pada section Contact di `index.html` dengan alamat email asli.
- **Favicon & thumbnail:** ganti file di `assets/icons/` dan `assets/images/` dengan gambar/logo asli (format apa pun, cukup sesuaikan ekstensi di `index.html`).

### Menambah Section Baru
1. Tambahkan `<section id="nama-section" class="section">` baru di `index.html`.
2. Tambahkan link navigasi baru di `.nav-links`.
3. Elemen dengan class `.reveal` akan otomatis mendapat animasi scroll-reveal.

---

## 🚀 Deploy ke GitHub Pages

1. Push seluruh isi folder ini ke repository GitHub (mis. `chulochuffed/chulochuffed.github.io` atau repo apa pun).
2. Aktifkan **GitHub Pages** di Settings → Pages → pilih branch `main` dan folder root (`/`).
3. Arahkan custom domain `chulochuffed.is-a.dev` melalui [is-a.dev](https://www.is-a.dev/) dengan menambahkan file `CNAME` berisi `chulochuffed.is-a.dev`, lalu submit pull request pendaftaran subdomain sesuai panduan is-a.dev.
4. Tunggu propagasi DNS, website akan langsung dapat diakses tanpa perlu perubahan kode tambahan.

> Catatan: file `CNAME` sengaja tidak disertakan secara default agar tidak konflik saat pratinjau lokal — tambahkan sendiri saat deploy (isi: `chulochuffed.is-a.dev`).

---

## 🧪 Menjalankan Secara Lokal

Karena website ini murni statis, cukup buka `index.html` langsung di browser, atau jalankan local server sederhana:

```bash
# Python
python3 -m http.server 8000

# Node.js
npx serve .
```

Lalu akses `http://localhost:8000`.

---

## 🛠️ Teknologi

- HTML5 semantik
- CSS3 (custom properties, Grid, Flexbox, `backdrop-filter`)
- JavaScript ES6+ murni (tanpa framework)
- [Font Awesome](https://fontawesome.com/) — ikon
- [Google Fonts](https://fonts.google.com/) — Space Grotesk, Inter, JetBrains Mono

---

## 📬 Kontak

- GitHub: [github.com/chulochuffed](https://github.com/chulochuffed)
- Instagram: [@chulo_chuffed](https://www.instagram.com/chulo_chuffed)
- Facebook: [chulo.chuffed](https://www.facebook.com/chulo.chuffed)
- TikTok: [@chulo.chuffed](https://www.tiktok.com/@chulo.chuffed)
- WhatsApp: [wa.me/qr/HBH3FQKKFIJAP1](https://wa.me/qr/HBH3FQKKFIJAP1)

---

© 2026 Chulo Chuffed. Ethical Hacker | Security Researcher | Bug Hunter
